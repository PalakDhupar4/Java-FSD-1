package Binary_Search;

import java.util.Scanner;

public class BinarySearch {

    public static  void main(String[] args){

    	
        int[] arr = {10,12,15,16,35};
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the element to be searched : ");
        int key = sc.nextInt();



        int arrlength = arr.length;
        int last=arrlength-1;
        binarySearch(arr,0,key,last);

    }

public static void binarySearch(int[] arr, int start, int key, int last){

        int midValue = (start+last)/2;
        while(start<=last){

            if(arr[midValue]<key){

                start = midValue + 1;
            } else if(arr[midValue]==key){
                System.out.println("Element is found at index :"+midValue);
                break;
            }else {

                last=midValue-1;
            }
            midValue = (start+last)/2;
        }
            if(start>last){

                System.out.println("Element is not found");
            }

}

}

