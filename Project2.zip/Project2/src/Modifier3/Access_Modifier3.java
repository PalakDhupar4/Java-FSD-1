package Modifier3;

public class Access_Modifier3 {

	protected void display() 
    { 
        System.out.println("This is protected access specifier."); 
    } 
}

