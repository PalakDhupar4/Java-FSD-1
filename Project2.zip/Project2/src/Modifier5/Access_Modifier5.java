package Modifier5;
public class Access_Modifier5 {

	public void display() 
    { 
        System.out.println("This is Public Access Specifiers."); 
    } 
}

