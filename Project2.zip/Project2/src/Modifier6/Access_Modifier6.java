package Modifier6;
import Modifier5.*;

public class Access_Modifier6 {

	public static void main(String[] args) {
		
		Access_Modifier5 obj = new Access_Modifier5(); 
        obj.display();  
		
	}
}


