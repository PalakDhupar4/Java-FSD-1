package Modifier2;
class priavateaccessmodifier 
{ 
	private void display() 
    { 
        System.out.println("You are using private access modifier"); 
    } 
} 

public class Access_Modifier2 {

	public static void main(String[] args) {
		//private
		System.out.println("Private Access Modifier.");
		priavateaccessmodifier obj = new priavateaccessmodifier(); 
        //trying to access private method of another class 
        //obj.display();

	}
}

