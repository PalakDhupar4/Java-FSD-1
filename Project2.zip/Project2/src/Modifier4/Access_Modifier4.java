package Modifier4;

import Modifier3.*;

public class Access_Modifier4 extends Access_Modifier3 {

	public static void main(String[] args) {
		Access_Modifier4 obj = new Access_Modifier4 ();   
	       obj.display();  
	}

}


