package Modifier;

class defAccessModifier
{ 
  void display() 
     { 
         System.out.println("You are using default access modifier."); 
     } 
} 

public class Access_Modifier {

	public static void main(String[] args) {
		//default
		System.out.println("Default Access Specifier");
		defAccessModifier obj = new defAccessModifier(); 		  
        obj.display(); 

	}
}
