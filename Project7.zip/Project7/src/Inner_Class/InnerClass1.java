package Inner_Class;
public class InnerClass1 {
	private String msg="Program of Inner Class"; 
 
	 
	 class Inner{  
	  void hello(){System.out.println(msg+"\nLet us initiate inner class");}  
	 }  


	public static void main(String[] args) {

		InnerClass1 obj=new InnerClass1();
		InnerClass1.Inner in=obj.new Inner();  
		in.hello();  
	}
}

