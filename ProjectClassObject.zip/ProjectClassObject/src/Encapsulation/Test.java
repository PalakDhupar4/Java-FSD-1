package Encapsulation;
public class Test 
{     
    public static void main (String[] args)  
    { 
        Encapsulate obj = new Encapsulate(); 
        obj.setName("Priya"); 
        obj.setAge(25); 
        obj.setRoll(61); 
        System.out.println("My name is: " + obj.getName()); 
        System.out.println("My age is: " + obj.getAge()); 
        System.out.println("My roll is: " + obj.getRoll());      
    } 
}

