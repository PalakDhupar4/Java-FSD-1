package Polymorphism;


class Multiply 
{
    public int multiply(int x, int y) 
    { 
        return (x * y); 
    } 
    public int multiply(int x, int y, int z) 
    { 
        return (x * y * z); 
    } 
    public double multiply(double x, double y) 
    { 
        return (x * y); 
    } 
    public static void main(String args[]) 
    { 
        Multiply m = new Multiply(); 
        System.out.println(m.multiply(5, 8)); 
        System.out.println(m.multiply(5, 8, 30)); 
        System.out.println(m.multiply(8.5, 10.5)); 
    } 
}
