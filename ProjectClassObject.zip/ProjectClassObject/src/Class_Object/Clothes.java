package Class_Object;
public class Clothes 
{  
    String name; 
    String Type; 
    int id; 
    String color; 
    public Clothes(String name, String type, int id, String color) 
    { 
        this.name = name; 
        this.Type = type; 
        this.id = id; 
        this.color = color; 
    } 
    public String getName() 
    { 
        return name; 
    } 
    public String getType() 
    { 
        return Type; 
    } 
    public int getId() 
    { 
        return id; 
    } 
    public String getColor() 
    { 
        return color; 
    } 
    @Override
    public String toString() 
    { 
        return("Name of Cloth: "+ this.getName()+ ".\nCloth Type is: " + this.getType()+ ".\nCloth Id is:  " + this.getId()+ ".\nCloth Color is: "+ this.getColor() + "."); 
    } 
    public static void main(String[] args) 
    { 
        Clothes c1 = new Clothes("Suits","Muslin", 101, "Majenta"); 
        System.out.println(c1.toString());
        Clothes c2 = new Clothes("Blazer","Warm", 203, "Black"); 
        System.out.println(c2.toString());
        
    } 
}

