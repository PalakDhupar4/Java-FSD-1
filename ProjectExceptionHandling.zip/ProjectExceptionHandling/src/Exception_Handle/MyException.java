package Exception_Handle;
class Demo extends Exception{
	   String x;
	   Demo(String y) {
		x=y;
	   }
	   public String toString(){ 
		return ("Exception Occurred: "+x) ;
	   }
	}
	class MyException{
	   public static void main(String args[]){
		try{
			System.out.println("Starting of try block");
			// I'm throwing the custom exception using throw
			throw new Demo("This is My error Message");
		}
		catch(Demo exp){
			System.out.println("Catch Block") ;
			System.out.println(exp) ;
		}
	   }
	}

