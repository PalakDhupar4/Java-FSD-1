package Regular_Expression;
import java.util.regex.*;

public class Regular {

public static void main(String[] args) {
 // way 1
	Pattern p= Pattern.compile(".s");
	Matcher m=p.matcher("as");
	boolean b=m.matches();
	
// Way 2
	boolean b2=Pattern.compile(".s").matcher("as").matches();
	
// Way 3
	boolean b3=Pattern.matches(".s", "as");
	
	System.out.println(b+" "+ b2+" "+ b3);
}
}
	

