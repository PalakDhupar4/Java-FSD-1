package Array;
public class ArrayClass {

public static void main(String[] args) {

//Single-dimensional array
int a[]= {10,20,30,40,50,60,70,80};
for(int i=0;i<8;i++) {
System.out.println("Elements of array are: "+a[i]);
}


//Multidimensional array
int[][] b = {
            {1, 2, 3}, 
            {4, 5, 6, 7} };
      
      System.out.println("\nLength of row 1: " + b[0].length);
      System.out.println("\nLength of row 2: " + b[1].length);
      }
}


