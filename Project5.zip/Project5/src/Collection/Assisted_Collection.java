package Collection;
import java.util.*;

public class Assisted_Collection {

	public static void main(String[] args) {
		
		//Creating Arraylist
		
		System.out.println("ArrayList is shown");
		ArrayList<String> name=new ArrayList<String>();   
	      name.add("Rashi");//
	      name.add("Aradhika");    	   
	      System.out.println(name);  
		
		//Creating Vector
	      System.out.println("\n");
	      System.out.println("Vector is shown");
	      Vector<Integer> vec = new Vector();
	      vec.addElement(45); 
	      vec.addElement(65); 
	      System.out.println(vec);
		
		//Creating Linked list
	      System.out.println("\n");
	      System.out.println("LinkedList is shown");
	      LinkedList<String> names=new LinkedList<String>();  
	      names.add("Shanaya");  
	      names.add("Malhotra");  	      
	      Iterator<String> itr=names.iterator(); 
	      while(itr.hasNext()) {
	       System.out.println(itr.next());
	      }
	       
	      //Creating Hash Set
	       System.out.println("\n");
	       System.out.println("HashSet is shown");
	       HashSet<Integer> set=new HashSet<Integer>();  
	       set.add(201);  
	       set.add(202);  
	       set.add(203);
	       set.add(204);
	       System.out.println(set);
	       
	      //Creating Linked Hash Set
	       System.out.println("\n");
	       System.out.println("LinkedHashSet is shown");
	       LinkedHashSet<Integer> set2=new LinkedHashSet<Integer>();  
	       set2.add(15);  
	       set2.add(20);  
	       set2.add(25);
	       set2.add(35);	       
	       System.out.println(set2);
	      	} 
	      }

	


