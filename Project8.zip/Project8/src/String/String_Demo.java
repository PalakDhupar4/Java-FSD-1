package String;
public class 	String_Demo {

	public static void main(String[] args) {
		//methods of strings
		System.out.println("Methods of Strings");
		
		String sl=new String("Project 8");
		System.out.println(sl.length());

		//substring
		String sub=new String("Strings");
		System.out.println(sub.substring(2));

		//String Comparison
		String s1="String";
		String s2="Strong";
		System.out.println(s1.compareTo(s2));

		//IsEmpty
		String s4="";
		System.out.println(s4.isEmpty());

		//toLowerCase
		String s5="String";
		System.out.println(s1.toLowerCase());
		
		//replace
		String s6="Strong";
		String replace=s2.replace('o', 'i');
		System.out.println(replace);

		//equals
		String x="String Methods";
		String y="StRiNg MeThOdS";
		System.out.println(x.equals(y));
 
		System.out.println("\n");
		System.out.println("Creating String Buffer");
		//Creating StringBuffer and append method
		StringBuffer s=new StringBuffer("tring Buffer!");
		s.append("Understand String Buffer");
		System.out.println(s);

		//insert method
		s.insert(0, 'S');
		System.out.println(s);

		//replace method
		StringBuffer sb=new StringBuffer("String");
		sb.replace(0, 2, "STR");
		System.out.println(sb);

		//delete method
		sb.delete(0, 1);
		System.out.println(sb);
		
		//StringBuilder
		System.out.println("\n");
		System.out.println("Creating String Builder");
		StringBuilder sb1=new StringBuilder("Enjoy");
		sb1.append("Programming");
		System.out.println(sb1);

		System.out.println(sb1.delete(0, 1));

		System.out.println(sb1.insert(1, "String"));

		System.out.println(sb1.reverse());
				
		//conversion	
		System.out.println("\n");
		System.out.println("Conversion of Strings to StringBuffer and StringBuilder");
		
		String str = "Buffer"; 
        
        // conversion from String object to StringBuffer 
        StringBuffer sbr = new StringBuffer(str); 
        sbr.reverse(); 
        System.out.println("String to String Buffer");
        System.out.println(sbr); 
          
        // conversion from String object to StringBuilder 
        StringBuilder sbl = new StringBuilder(str); 
        sbl.append("Buffer"); 
        System.out.println("String to String Builder");
        System.out.println(sbl);              		
	}
}


