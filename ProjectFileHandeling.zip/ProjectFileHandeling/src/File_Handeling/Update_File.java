package File_Handeling;
import java.io.File;
import java.io.IOException;
import java.io.FileWriter;

// Update a file
public class Update_File 
{ 
  
  public static void main(String[] args) 
  {
	  try {
		  FileWriter u = new FileWriter("filename.txt");
          u.write("Welcome to  Java Program of File Handeling.");
          u.close();
          System.out.println("Successfully Updated to the file.");
	  }
	  catch(IOException e) {
		  System.out.println("An error occurred.");
		  e.printStackTrace();
	  }
	  }
  }