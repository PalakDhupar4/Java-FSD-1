package File_Handeling;
import java.io.File;// Import file class
public class Delete_File{
	public static void main(String[]args) {
		File f = new File("filename.txt");
		if(f.delete()) {
			System.out.println("Deleted the File");
		}
		else {
			System.out.println("Failed to delete the file.");
		}
	}
}

