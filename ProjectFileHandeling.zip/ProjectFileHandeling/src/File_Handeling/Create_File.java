package File_Handeling;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileWriter;
 
public class Create_File
{
    
 
    public static void  main(String[]args)
    {
       try {
       File f=new File("filename.txt");
  
          //Create the file
          if (f.createNewFile()){
            System.out.println("File is created!");
          }else{
            System.out.println("File already exists.");
          }
          // Write in the file
          FileWriter myWriter = new FileWriter("filename.txt");
          myWriter.write("Welcome to file Handelling.");
          myWriter.close();
          System.out.println("Successfully wrote to the file.");
          
           
    }
       catch(IOException e) {
    	   System.out.println("An error occurred.");
    	   e.printStackTrace();
       }
    }
}
 
    
