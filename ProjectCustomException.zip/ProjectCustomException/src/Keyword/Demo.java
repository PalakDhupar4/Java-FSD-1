package Keyword;
public class Demo
{
    public static void main(String[] args)
    {

        float a=55,b=8,result;

        try
        {
            if(b==0)        
                throw(new ArithmeticException(" It Can't be divided by zero."));
            else
            {
                result = a / b;
                System.out.print("\n\tThe result is of the operation : " + result);
            }
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("\n\tError : " + Ex.getMessage());
        }

        System.out.print("\n\tEnd of program.");
    }
}

