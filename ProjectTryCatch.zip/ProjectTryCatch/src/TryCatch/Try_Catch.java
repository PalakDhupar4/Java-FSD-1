package TryCatch;
public class Try_Catch 
{
    public static void main(String args[]) 
    {
        int[] array = new int[4];
        try 
        {
            array[8] = 4;
        }
        catch (ArrayIndexOutOfBoundsException e) 
        {
            System.out.println("Array index is out of bounds!"); 
        }
        finally 
        {
            System.out.println("The size of Array is " + array.length);
        }
    }
}

