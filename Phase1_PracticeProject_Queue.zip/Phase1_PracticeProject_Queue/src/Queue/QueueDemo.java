package Queue;
class Queue{
	public static int front,rear,capacity;
	public static int queue[];
	
	Queue(int size){
		front = rear =0;
		capacity = size;
		queue = new int[capacity];
	}
	
	//insert an element into the queue
	static void queueEnqueue(int item) {
		
		//check queue is full
		if(capacity == rear) {
			System.out.println("\n Queue is Full");
			return;
		}
		
		//insert an element at rear end
		else {
			queue[rear] = item;
			rear++;
		}
		return;
	}
	
	//remove an element from queue
	static void queueDequeue() {
		
		//check if queue is empty
		if(front == rear) {
			System.out.println("\n Queue is empty\n");
			return;
		}
		else {
			for(int i=0;i<rear-1;i++) {
			     queue[i] = queue[i+1];	
			}
			if(rear<capacity)
				queue[rear]=0;
			rear--;
		}
		return;
	}
	//print queue elements
	static void queueDisplay() {
		int i;
		if(front == rear) {
			System.out.println("\nQueue is empty\n");
			return;
		}
		
		//traverse from front to rear and print elements
		for(i=front;i<rear;i++) {
			System.out.printf("%d,", queue[i]);
		}
		return;
	}
}
public class QueueDemo{
	public static void main(String[] args) {
		Queue q = new Queue(4);
		System.out.println("Initial Queue.");
		
		q.queueDisplay();
		q.queueEnqueue(10);
		q.queueEnqueue(20);
		q.queueEnqueue(30);
		q.queueEnqueue(40);
		
		System.out.println("Queue after insertion : ");
		q.queueDisplay();
		
		
		q.queueDequeue();
		q.queueDequeue();
		System.out.println("\nQueue after removing two elements");
		q.queueDisplay();
		
	}
}
