package Methods;
public class method_execution {

public int substract(int x,int y) {
	int z=x-y;
	return z;
}

public static void main(String[] args) {

	method_execution y=new method_execution();
	int ans= y.substract(45,28);
	System.out.println("Substraction is :"+ans);
	}

}