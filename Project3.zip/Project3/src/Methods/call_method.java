package Methods;
public class call_method {

int num=300;

int operation(int num) {
	num =(num*10)/100;
	return(num);
}

public static void main(String args[]) {
	call_method d = new call_method();
	System.out.println("Before operation value of data is "+d.num);
	d.operation(100);
	System.out.println("After operation value of data is "+d.num);
	}
}

