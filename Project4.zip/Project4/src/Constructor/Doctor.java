package Constructor;
class Doc_info{
	int id;
	String name;

	Doc_info(int i,String n)
	{
	id=i;
	name=n;
	}

	void display() {
	System.out.println(id+" "+name);
	}
}

public class Doctor {
public static void main(String[] args) {

	Doc_info d1=new Doc_info(2,"Palak");
	Doc_info d2=new Doc_info(3,"Prachi");
	Doc_info d3=new Doc_info(4,"Shreya");
	Doc_info d4=new Doc_info(5,"Megha");
	d1.display();
	d2.display();
	d3.display();
	d4.display();
		}
}
